import React from "react";
import { ApplicationsSection } from "./sections/ApplicationsSection/ApplicationsSection";
import { OverviewSection } from "./sections/OverviewSection";
import { StatisticsSection } from "./sections/StatisticsSection";

export const Dashboard = (): JSX.Element => {
  return (
    <main className="flex min-h-screen bg-soft-grey">
      <div className="flex flex-col w-full">
        <div className="flex w-full">
          {/* Top navigation bars */}
          <div className="z-10 flex h-9 items-center justify-between p-2 flex-1 bg-[#f1f1f1] rounded" />
          <div className="z-0 flex h-9 items-center justify-between p-2 flex-1 bg-[#f1f1f1] rounded" />
        </div>

        {/* Main content container */}
        <div className="w-full flex flex-col">
          <div className="gap-6 px-6 py-8 w-full bg-[#f9f9f9] flex flex-col">
            <OverviewSection />
            <StatisticsSection />
            <ApplicationsSection />
          </div>
        </div>
      </div>
    </main>
  );
};
