import React from "react";
import { Badge } from "../../../../components/ui/badge";
import { Card, CardContent } from "../../../../components/ui/card";

export const StatisticsSection = (): JSX.Element => {
  // Data for statistics cards
  const statisticsCards = [
    {
      title: "All Applications",
      value: "24",
      icon: "/app-folder.svg",
      iconBg: "bg-purplepurple-50",
      badges: [
        {
          text: "4 Approved",
          bg: "bg-[#e9f7ee]",
          valueColor: "text-[#1fb356]",
          labelColor: "text-[#5d606d]",
        },
        {
          text: "3 Pending",
          bg: "bg-[#fdf7e6]",
          valueColor: "text-[#edbd33]",
          labelColor: "text-[#5d606d]",
        },
        {
          text: "1 Cancel",
          bg: "bg-[#fdeaea]",
          valueColor: "text-[#eb5858]",
          labelColor: "text-[#5d606d]",
        },
      ],
    },
    {
      title: "All Bookings",
      value: "03",
      icon: "/calendar-date.svg",
      iconBg: "bg-greengreen-50",
      badges: [],
    },
    {
      title: "All Reviews",
      value: "4.5",
      icon: "/book-star.svg",
      iconBg: "bg-[#e6f6fd]",
      subtitle: {
        value: "4.5",
        name: "Sarah Malik",
        valueColor: "text-[#009af3]",
      },
    },
    {
      title: "All Listings",
      value: "03",
      icon: "/document-queue.svg",
      iconBg: "bg-[#fff3ec]",
      subtitle: { text: "Listed Properties" },
    },
  ];

  return (
    <div className="w-full flex items-start gap-6 relative">
      {statisticsCards.map((card, index) => (
        <Card
          key={index}
          className="flex-1 border border-solid border-[#e9eaea] rounded-[20px] overflow-hidden"
        >
          <CardContent className="flex flex-col items-start gap-4 p-5">
            <div className="flex gap-4 self-stretch w-full items-start">
              <div className="flex flex-col gap-2 flex-1 items-start">
                <div className="self-stretch mt-[-1.00px] font-['Poppins',Helvetica] font-medium text-blackblack-500 text-base leading-6">
                  {card.title}
                </div>
              </div>

              <div
                className={`flex w-10 h-10 items-center justify-center gap-2 p-2 ${card.iconBg} rounded-[100px] overflow-hidden`}
              >
                <img className="w-6 h-6" alt={card.title} src={card.icon} />
              </div>
            </div>

            <div className="flex items-start gap-4 self-stretch w-full">
              <div
                className={`flex ${card.badges?.length ? "flex-1" : "min-w-[120px]"} flex-col items-start gap-4`}
              >
                <div className="self-stretch mt-[-1.00px] font-['Poppins',Helvetica] font-medium text-blackblack-500 text-[28px] leading-[33.6px]">
                  {card.value}
                </div>

                {card.badges && card.badges.length > 0 && (
                  <div className="flex items-center justify-between w-full">
                    {card.badges.map((badge, badgeIndex) => (
                      <Badge
                        key={badgeIndex}
                        className={`px-2 py-1 ${badge.bg} rounded-[100px] font-normal`}
                      >
                        <span className={`${badge.valueColor} leading-[0.1px]`}>
                          {badge.text.split(" ")[0]}{" "}
                        </span>
                        <span className={`${badge.labelColor} leading-[18px]`}>
                          {badge.text.split(" ")[1]}
                        </span>
                      </Badge>
                    ))}
                  </div>
                )}

                {card.subtitle && (
                  <div className="flex items-center gap-1 self-stretch w-full">
                    {card.subtitle.value && (
                      <div className="inline-flex items-center">
                        <div
                          className={`w-fit mt-[-1.00px] font-body-base-semibold font-[number:var(--body-base-semibold-font-weight)] ${card.subtitle.valueColor} text-[length:var(--body-base-semibold-font-size)] tracking-[var(--body-base-semibold-letter-spacing)] leading-[var(--body-base-semibold-line-height)] whitespace-nowrap [font-style:var(--body-base-semibold-font-style)]`}
                        >
                          {card.subtitle.value}
                        </div>
                      </div>
                    )}
                    <div className="w-fit mt-[-1.00px] font-['Poppins',Helvetica] font-normal text-greygrey-500 text-sm leading-[21px] whitespace-nowrap">
                      {card.subtitle.name || card.subtitle.text}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
