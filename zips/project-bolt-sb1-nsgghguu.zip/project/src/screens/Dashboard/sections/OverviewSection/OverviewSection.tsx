import React from "react";

export const OverviewSection = (): JSX.Element => {
  return (
    <section className="w-full">
      <div className="flex flex-col gap-2">
        <h2 className="font-medium text-2xl text-blackblack-500 leading-[28.8px] font-['Poppins',Helvetica]">
          Overview
        </h2>
        <p className="text-lg text-greygrey-500 font-normal leading-[27px] font-['Poppins',Helvetica]">
          Hello John, here&apos;s what happen with your store
        </p>
      </div>
    </section>
  );
};
