import { ChevronDownIcon, ChevronUpIcon, MoreVerticalIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../../../../components/ui/card";

export const ApplicationsSection = (): JSX.Element => {
  // Application status data with colors
  const statusTypes = [
    { name: "Approved", color: "#1fb356" },
    { name: "Pending", color: "#edbd33" },
    { name: "Declined", color: "#e62e2e" },
  ];

  // Y-axis values for Applications chart
  const yAxisValues = ["2k", "1k", "800", "600", "400", "200", "0"];

  // Months data for both charts
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "June",
    "July",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];

  // Bar chart data for each month
  const barChartData = [
    {
      month: "Jan",
      approved: { height: "h-[50px]" },
      pending: { height: "h-5" },
      declined: { height: "h-8" },
    },
    {
      month: "Feb",
      approved: { height: "h-[86px]" },
      pending: { height: "h-[42px]" },
      declined: { height: "h-[62px]" },
    },
    {
      month: "Mar",
      approved: { height: "h-[50px]" },
      pending: { height: "h-12" },
      declined: { height: "h-[59px]" },
    },
    {
      month: "Apr",
      approved: { height: "h-[22px]" },
      pending: { height: "h-[154px]" },
      declined: { height: "h-8" },
    },
    {
      month: "May",
      approved: { height: "h-[101px]" },
      pending: { height: "h-[33px]" },
      declined: { height: "h-[110px]" },
    },
    {
      month: "June",
      approved: { height: "h-[50px]" },
      pending: { height: "h-[92px]" },
      declined: { height: "h-8" },
    },
    {
      month: "July",
      approved: { height: "h-[76px]" },
      pending: { height: "h-4" },
      declined: { height: "h-11" },
    },
    {
      month: "Aug",
      approved: { height: "h-[143px]" },
      pending: { height: "h-[54px]" },
      declined: { height: "h-[30px]" },
    },
    {
      month: "Sep",
      approved: { height: "h-[29px]" },
      pending: { height: "h-[81px]" },
      declined: { height: "h-[30px]" },
    },
    {
      month: "Oct",
      approved: { height: "h-[127px]" },
      pending: { height: "h-[74px]" },
      declined: { height: "h-[31px]" },
    },
    {
      month: "Nov",
      approved: { height: "h-[49px]" },
      pending: { height: "h-[47px]" },
      declined: { height: "h-[31px]" },
    },
    {
      month: "Dec",
      approved: { height: "h-[95px]" },
      pending: { height: "h-16" },
      declined: { height: "h-[65px]" },
    },
  ];

  // Rent chart Y-axis values
  const rentYAxisValues = ["100", "80", "60", "40", "20", "0"];

  return (
    <div className="flex items-start gap-6 w-full">
      <Card className="flex-1 border border-[#e9eaea] rounded-[20px]">
        <CardHeader className="flex flex-row items-center justify-between px-6 py-[18px] border-b border-[#e9eaea]">
          <div className="flex flex-col gap-0.5">
            <CardTitle className="font-bold text-lg text-blackblack-500 [font-family:'Poppins',Helvetica] leading-[27px]">
              Applications
            </CardTitle>
            <CardDescription className="font-medium text-sm text-greygrey-500 [font-family:'Poppins',Helvetica] leading-[21px]">
              Lorem ipsum dolor sit amet.
            </CardDescription>
          </div>
          <Button variant="ghost" size="icon" className="w-6 h-6 p-0">
            <MoreVerticalIcon className="w-[18px] h-[18px]" />
          </Button>
        </CardHeader>

        <CardContent className="p-6 flex flex-col gap-8">
          <div className="flex gap-8 items-center">
            {statusTypes.map((status, index) => (
              <div key={index} className="inline-flex gap-1.5 items-center">
                <div
                  className="w-3 h-3 rounded-md"
                  style={{ backgroundColor: status.color }}
                />
                <span className="font-normal text-sm text-greygrey-500 [font-family:'Poppins',Helvetica] leading-[21px]">
                  {status.name}
                </span>
              </div>
            ))}
          </div>

          <div className="relative h-[337px] w-full">
            <div className="flex flex-col h-[313px] gap-[18px]">
              {yAxisValues.map((value, index) => (
                <div key={index} className="h-8 flex items-center gap-2 w-full">
                  <div className="w-10 font-normal text-xs text-greygrey-500 [font-family:'Poppins',Helvetica] text-right leading-[16.8px]">
                    {value}
                  </div>
                  <div className="flex-1 h-px bg-[url(/line.svg)] bg-cover" />
                </div>
              ))}
            </div>

            <div className="flex items-end absolute top-6 left-12 w-[464px] h-[313px]">
              {barChartData.map((data, index) => (
                <div
                  key={index}
                  className="flex flex-col items-center justify-end gap-[9px] flex-1"
                >
                  <div className="inline-flex flex-col items-start justify-end gap-1">
                    <div
                      className={`w-2 ${data.declined.height} bg-[#e62e2e] rounded-[10px]`}
                    />
                    <div
                      className={`w-2 ${data.pending.height} bg-[#edbd33] rounded-[10px]`}
                    />
                    <div
                      className={`w-2 ${data.approved.height} bg-[#1fb356] rounded-[10px]`}
                    />
                  </div>
                  <div
                    className={`w-fit font-normal text-xs text-center leading-[16.8px] ${data.month === "July" ? "text-[#edbd33]" : "text-greygrey-500"} [font-family:'Poppins',Helvetica]`}
                  >
                    {data.month}
                  </div>
                </div>
              ))}
            </div>

            <div className="absolute top-[43px] left-[215px] bg-white rounded-xl border border-[#e9eaea] shadow-soft-shadow p-3 flex flex-col gap-1.5">
              {[
                {
                  color: "#1fb356",
                  name: "Approved",
                  value: "180",
                  icon: <ChevronUpIcon className="w-4 h-4" />,
                },
                {
                  color: "#edbd33",
                  name: "Pending",
                  value: "180",
                  icon: <ChevronDownIcon className="w-4 h-4" />,
                },
                {
                  color: "#e62e2e",
                  name: "Deeclined",
                  value: "100",
                  icon: <ChevronDownIcon className="w-4 h-4" />,
                },
              ].map((item, index) => (
                <div key={index} className="inline-flex gap-1 items-center">
                  <div
                    className="w-2.5 h-2.5 rounded-[5px]"
                    style={{ backgroundColor: item.color }}
                  />
                  <div
                    className="w-[75px] text-xs leading-[16.8px] [font-family:'Poppins',Helvetica]"
                    style={{ color: item.color }}
                  >
                    {item.name}
                  </div>
                  <div className="w-[7px] text-greygrey-500 font-text-s-regular">
                    :
                  </div>
                  <div
                    className="font-body-small-semibold"
                    style={{ color: item.color }}
                  >
                    {item.value}
                  </div>
                  {item.icon}
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="flex-1 border border-[#e9e9eb] rounded-xl shadow-shadows-shadow-xs">
        <CardHeader className="flex flex-row items-center justify-between px-6 py-[18px] border-b border-[#e9eaea]">
          <div className="flex flex-col gap-0.5">
            <CardTitle className="font-bold text-lg text-blackblack-500 [font-family:'Poppins',Helvetica] leading-[27px]">
              Incoming Rent
            </CardTitle>
            <CardDescription className="font-medium text-sm text-greygrey-500 [font-family:'Poppins',Helvetica] leading-[21px]">
              Amount of rent received each month
            </CardDescription>
          </div>
          <Button variant="ghost" size="icon" className="w-6 h-6 p-0">
            <MoreVerticalIcon className="w-[18px] h-[18px]" />
          </Button>
        </CardHeader>

        <CardContent className="p-6 flex flex-col gap-6 h-full">
          <div className="relative flex-1 w-full">
            <div className="w-full h-[462px]">
              <div className="flex flex-col w-full">
                <div className="flex flex-col w-full">
                  {rentYAxisValues.map((value, index) => (
                    <div
                      key={index}
                      className="h-[17px] flex items-center gap-2 w-full"
                    >
                      <div className="w-10 font-normal text-xs text-[#535861] [font-family:'Poppins',Helvetica] text-right leading-[18px]">
                        {value}
                      </div>
                      <div className="flex-1 h-px bg-[url(/divider.svg)] bg-cover bg-[50%_50%]" />
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pl-16 pr-6 py-0 w-full mt-4">
                  {months.map((month, index) => (
                    <div
                      key={index}
                      className="font-normal text-xs text-[#535861] [font-family:'Poppins',Helvetica] text-center leading-[18px]"
                    >
                      {month.substring(0, 3)}
                    </div>
                  ))}
                </div>

                <div className="absolute w-[464px] h-[410px] top-0 left-12 overflow-hidden">
                  <div className="relative w-[1600px] h-[410px] left-[-568px]">
                    <div className="relative w-[464px] h-[410px] left-[568px]">
                      <img
                        className="absolute w-[464px] h-[361px] top-[49px] left-0"
                        alt="Background"
                        src="/background.png"
                      />
                      <img
                        className="absolute w-[464px] h-[410px] top-0 left-0"
                        alt="Lines background"
                        src="/lines-background.png"
                      />
                      <img
                        className="absolute w-[464px] h-[143px] top-[104px] left-0"
                        alt="Line"
                        src="/line-3.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
