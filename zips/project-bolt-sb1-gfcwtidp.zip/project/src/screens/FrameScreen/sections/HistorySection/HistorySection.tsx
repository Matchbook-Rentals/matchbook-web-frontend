import React from "react";
import { Tabs, TabsList, TabsTrigger } from "../../../../components/ui/tabs";

export const HistorySection = (): JSX.Element => {
  // Data for the tabs
  const tabOptions = [
    { value: "upcoming", label: "Upcoming" },
    { value: "history", label: "History" },
  ];

  return (
    <Tabs defaultValue="upcoming" className="w-full">
      <TabsList className="flex h-auto p-0 bg-transparent gap-1 rounded-md">
        {tabOptions.map((tab) => (
          <TabsTrigger
            key={tab.value}
            value={tab.value}
            className={`flex items-center justify-center px-4 py-3 rounded-md data-[state=active]:border-b-2 data-[state=active]:border-[#0b6969] data-[state=active]:shadow-none data-[state=active]:bg-transparent data-[state=active]:text-primaryprimary-500 data-[state=active]:font-medium data-[state=inactive]:text-[#717680] data-[state=inactive]:font-normal data-[state=active]:text-base data-[state=inactive]:text-sm`}
          >
            {tab.label}
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  );
};
