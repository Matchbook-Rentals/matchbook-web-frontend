import React from "react";
import { HistorySection } from "./sections/HistorySection";
import { UpcomingSection } from "./sections/UpcomingSection/UpcomingSection";

export const FrameScreen = (): JSX.Element => {
  return (
    <main className="flex flex-col w-full">
      <HistorySection />
      <UpcomingSection />
    </main>
  );
};
