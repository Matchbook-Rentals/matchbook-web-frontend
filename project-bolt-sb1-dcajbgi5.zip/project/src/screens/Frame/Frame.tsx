import { BookOpenIcon, CheckIcon, HeartIcon, SearchIcon } from "lucide-react";
import React from "react";

export const Frame = (): JSX.Element => {
  const steps = [
    {
      id: 1,
      title: "Search",
      icon: <SearchIcon className="w-11 h-11" />,
      position: "top-[273px] left-[17px]",
      bgImage: "/vector-1.svg",
      iconPosition: "top-[168px] left-[25px]",
    },
    {
      id: 2,
      title: "Favorite",
      icon: <HeartIcon className="w-11 h-11" />,
      position: "top-20 left-[228px]",
      bgImage: "/vector-7.svg",
      iconPosition: "top-[137px] left-0",
    },
    {
      id: 3,
      title: "Apply",
      icon: <CheckIcon className="w-11 h-11" />,
      position: "top-4 left-[576px]",
      bgImage: "/vector.svg",
      iconPosition: "top-[140px] left-[154px]",
    },
    {
      id: 4,
      title: "Match & Book",
      icon: <BookOpenIcon className="w-11 h-11" />,
      position: "top-[374px] left-[752px]",
      bgImage: "/vector-6.svg",
      iconPosition: "top-[170px] left-[153px]",
    },
  ];

  return (
    <section className="flex flex-col items-center gap-14 px-[150px] py-16 relative bg-[#fbfbfb]">
      <header className="inline-flex flex-col items-center gap-1 relative">
        <h1 className="relative w-fit mt-[-1.00px] font-['Poppins',Helvetica] font-medium text-gray-neutral900 text-[40px] tracking-[-2.00px] leading-[normal]">
          How MatchBook Works
        </h1>
      </header>

      <div className="relative w-[976px] h-[598px]">
        <div className="relative w-[975px] h-[597px] left-px bg-[url(/vector-5.svg)] bg-[100%_100%]">
          {steps.map((step) => (
            <div
              key={step.id}
              className={`absolute w-[200px] h-[214px] ${step.position}`}
            >
              <img
                className="absolute w-[200px] h-[200px] top-0 left-0"
                alt={`${step.title} background`}
                src={step.bgImage}
              />
              <div className="absolute w-full top-[65px] left-0 text-center font-['Poppins',Helvetica] font-medium text-gray-neutral700 text-3xl tracking-[0] leading-[normal]">
                {step.title}
              </div>
              <div className={`absolute ${step.iconPosition}`}>{step.icon}</div>
            </div>
          ))}

          {/* House illustration in the center */}
          <div className="absolute w-[231px] h-[231px] top-[276px] left-[405px] bg-[url(/vector-8.svg)] bg-[100%_100%]">
            <img
              className="absolute w-[136px] h-[132px] top-[49px] left-12"
              alt="House illustration"
              src="/download--1--1.png"
            />
          </div>

          {/* Connecting arrows */}
          <img
            className="absolute w-10 h-[58px] top-[285px] left-[262px]"
            alt="Arrow from Search to Favorite"
            src="/vector-3.svg"
          />

          <img
            className="absolute w-[85px] h-[89px] top-[148px] left-[477px]"
            alt="Arrow from Favorite to Apply"
            src="/vector-4.svg"
          />

          <img
            className="absolute w-[98px] h-[114px] top-[258px] left-[657px]"
            alt="Arrow from Apply to Match & Book"
            src="/vector-5-1.svg"
          />

          {/* Additional element for Favorite step */}
          <img
            className="absolute w-1.5 h-1.5 top-[172px] left-[230px]"
            alt="Favorite decoration"
            src="/vector-2.svg"
          />
        </div>
      </div>
    </section>
  );
};
